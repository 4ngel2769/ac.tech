
[By installing or using this font, you are agree to the Product Usage Agreement]

=============================== [ 0 ] =========================================
	    This font is for PERSONAL USE ONLY (Non-Profit Activity).
	          [ NOT ALLOWED for Commercial Use ] in any form.
===============================================================================

We Recommend you to buy Commercial License (Starting from US$14) & you will get :

1. legally, using font for profitable purposes (As per Purchased License).
2. Has exclusivity of the font (As per Purchased License).
3. One time purchases. Commercial use forever (As per Purchased License).
 
=============================== [ 1 ] =========================================

if you are interested in buying it, you can check this link : https://www.creativefabrica.com/designer/jadatype/ref/236165
or contact me for detailed license : jadaakbaaal@gmail.com


============================ Thank you ========================================
